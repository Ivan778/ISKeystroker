//
//  ISKeystrokeDynamics.h
//  ISKeystrokeDynamics
//
//  Created by Иван on 5/15/19.
//  Copyright © 2019 Ivan. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ISKeystrokeDynamics.
FOUNDATION_EXPORT double ISKeystrokeDynamicsVersionNumber;

//! Project version string for ISKeystrokeDynamics.
FOUNDATION_EXPORT const unsigned char ISKeystrokeDynamicsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ISKeystrokeDynamics/PublicHeader.h>
#import "ISKeystrokeDynamicsRecognitionModulesHandler.h"
#include "ISApplication.h"
