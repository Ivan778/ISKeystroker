//
//  ISTextField.h
//  KeyboardTest
//
//  Created by Иван on 3/17/19.
//  Copyright © 2019 Ivan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ISTextField : UITextField
@end
